package com.example.myapplication

import android.content.Intent
import android.os.Bundle
import android.widget.Button
import android.widget.ImageView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.firestore.FirebaseFirestore

data class DiarioItem(val atividade: String, val dataHora: String)

class Diario : AppCompatActivity() {
    private lateinit var recyclerDiary: RecyclerView
    private lateinit var auth: FirebaseAuth
    private lateinit var firestore: FirebaseFirestore
    private lateinit var ttsManager: TTSManager

    override fun onCreate(savedInstanceState: Bundle?) {
        ttsManager = TTSManager(this)

        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_diario)

        recyclerDiary = findViewById(R.id.recycler_diary)
        val btnBack = findViewById<ImageView>(R.id.btnBack)
        val btnAdd = findViewById<Button>(R.id.btnAdd)

        // Navbar botões
        val btnMenuPrincipal = findViewById<ImageView>(R.id.btnMenuPrincipal)
        val btnConfig = findViewById<ImageView>(R.id.btnConfig)
        val btnMicrophone = findViewById<ImageView>(R.id.btnMicrophone)
        val btnCamera = findViewById<ImageView>(R.id.btnCamera)

        btnBack.setOnClickListener { finish() }
        btnAdd.setOnClickListener {
            val intent = Intent(this, AddDiario::class.java)
            startActivity(intent)
        }

        btnMenuPrincipal.setOnClickListener {
            finish()
        }

        btnConfig.setOnClickListener {
            val intent = Intent(this, Configuracoes::class.java)
            startActivity(intent)
        }

        btnMicrophone.setOnClickListener {
            ttsManager.speak("Na tela de Diario ,Você pode visualizar as atividades adicionadas pelo usuario e adicionar mais.")
            Toast.makeText(this, "Text-to-Speech acionado.", Toast.LENGTH_SHORT).show()
        }

        btnCamera.setOnClickListener {
            finish()
            val intent = Intent(this, GeminiMenu::class.java)
            startActivity(intent)        }

        auth = FirebaseAuth.getInstance()
        firestore = FirebaseFirestore.getInstance()

        recyclerDiary.layoutManager = LinearLayoutManager(this)
        recyclerDiary.adapter = DiarioAdapter(emptyList())
    }

    override fun onResume() {
        super.onResume()
        loadDiaryItems() // Recarregar os itens ao voltar para a tela
    }

    private fun loadDiaryItems() {
        val currentUser = auth.currentUser
        if (currentUser == null) {
            Toast.makeText(this, "Usuário não autenticado", Toast.LENGTH_SHORT).show()
            return
        }

        val userId = currentUser.uid
        firestore.collection("atividades").document(userId).collection("diario")
            .get()
            .addOnSuccessListener { querySnapshot ->
                val diaryItems = querySnapshot.documents.mapNotNull { document ->
                    val atividade = document.getString("atividade") ?: return@mapNotNull null
                    val data = document.getString("data") ?: "Data desconhecida"
                    val hora = document.getString("hora") ?: "Hora desconhecida"
                    val timestamp = "$data $hora" // Combinação de data e hora para ordenação
                    DiarioItem(atividade, timestamp)
                }

                // Ordenar por data e hora decrescente
                val sortedItems = diaryItems.sortedByDescending { it.dataHora }

                // Atualizar o adaptador com os itens ordenados
                recyclerDiary.adapter = DiarioAdapter(sortedItems)
            }
            .addOnFailureListener { exception ->
                Toast.makeText(this, "Erro ao carregar atividades: ${exception.message}", Toast.LENGTH_SHORT).show()
            }
    }
    override fun onDestroy() {
        super.onDestroy()
        ttsManager.shutdown() // Libera recursos do TTS
    }

}
