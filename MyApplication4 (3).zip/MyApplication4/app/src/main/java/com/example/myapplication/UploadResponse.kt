package com.example.myapplication

data class UploadResponse(
    val success: Boolean,
    val message: String,
    val data: Any? // Substitua pelo formato de dados retornados pela API
)
