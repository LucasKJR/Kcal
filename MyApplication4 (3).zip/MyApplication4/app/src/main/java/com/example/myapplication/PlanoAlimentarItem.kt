package com.example.myapplication

data class PlanoAlimentarItem(
    val refeicao: String, // Nome da refeição
    val hora: String      // Hora da refeição
)
