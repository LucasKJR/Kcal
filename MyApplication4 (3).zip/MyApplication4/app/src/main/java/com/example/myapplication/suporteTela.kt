package com.example.myapplication

import android.annotation.SuppressLint
import android.content.Intent
import android.graphics.Rect
import android.os.Build
import android.os.Bundle
import android.speech.tts.TextToSpeech
import android.util.Log
import android.view.MotionEvent
import android.view.View
import android.widget.Button
import android.widget.EditText
import android.widget.ImageButton
import android.widget.TextView
import androidx.activity.enableEdgeToEdge
import androidx.annotation.RequiresApi
import androidx.appcompat.app.AppCompatActivity
import java.util.Locale

class suporteTela : AppCompatActivity(), TextToSpeech.OnInitListener {

    // Declaração dos botões
    private lateinit var buttonVoltar: Button
    private lateinit var buttonEditNome: Button
    private lateinit var buttonEditCondAlim: Button
    private lateinit var buttonEditAlergia: Button

    // Declaração dos TextViews
    private lateinit var textViewCabecalho: TextView
    private lateinit var textViewNome: TextView
    private lateinit var textViewCondAlim: TextView
    private lateinit var textViewAlergia: TextView

    // Declaração dos EditTexts
    private lateinit var editTextNome: EditText
    private lateinit var editTextCondAlim: EditText
    private lateinit var editTextAlergia: EditText

    // Declaração da ImageButton
    private lateinit var fotoImageButton: ImageButton

    // Declaração do TextToSpeech
    private lateinit var tts: TextToSpeech

    private var lastSpokenButton: String? = null // Evitar repetição desnecessária de áudio

    @RequiresApi(Build.VERSION_CODES.R)
    @SuppressLint("MissingInflatedId", "ClickableViewAccessibility", "SuspiciousIndentation")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContentView(R.layout.activity_suporte_tela)

        // Inicializando os itens declarados ANTES de usá-los
        buttonVoltar = findViewById(R.id.buttonVoltar)
        buttonEditNome = findViewById(R.id.btnEditarNome)
        buttonEditCondAlim = findViewById(R.id.btnEditarCondAlimentar)
        buttonEditAlergia = findViewById(R.id.btnEditarAlergia)

        textViewCabecalho = findViewById(R.id.cabecalhoTextView)
        textViewNome = findViewById(R.id.nomeTextView)
        textViewCondAlim = findViewById(R.id.condAlimTextView)
        textViewAlergia = findViewById(R.id.alergiaTextView)

        editTextNome = findViewById(R.id.editTextNome)
        editTextCondAlim = findViewById(R.id.condAlimEditText)
        editTextAlergia = findViewById(R.id.alergiaEditText)

        fotoImageButton = findViewById(R.id.imageButton)

        // Configurando o clique do botão "Voltar" DEPOIS de referenciar o ID corretamente
        buttonVoltar.setOnClickListener {
            val intent = Intent(this, Menu1::class.java)
            startActivity(intent)
        }

        // Inicializar o TextToSpeech
        tts = TextToSpeech(this, this)
    }

    override fun dispatchTouchEvent(event: MotionEvent?): Boolean {
        event?.let {
            val x = it.rawX
            val y = it.rawY

            Log.d("TouchCoords", "Coordenadas X: $x, Y: $y")

            val viewTextMap = mapOf(
                R.id.buttonVoltar to findViewById<Button>(R.id.buttonVoltar).text.toString(),
                R.id.btnEditarNome to findViewById<Button>(R.id.btnEditarNome).text.toString(),
                R.id.btnEditarCondAlimentar to findViewById<Button>(R.id.btnEditarCondAlimentar).text.toString(),
                R.id.btnEditarAlergia to findViewById<Button>(R.id.btnEditarAlergia).text.toString(),

                R.id.cabecalhoTextView to findViewById<TextView>(R.id.cabecalhoTextView).text.toString(),
                R.id.nomeTextView to findViewById<TextView>(R.id.nomeTextView).text.toString(),
                R.id.condAlimTextView to findViewById<TextView>(R.id.condAlimTextView).text.toString(),
                R.id.alergiaTextView to findViewById<TextView>(R.id.alergiaTextView).text.toString(),

                R.id.alergiaEditText to findViewById<EditText>(R.id.alergiaEditText).text.toString(),
                R.id.condAlimEditText to findViewById<EditText>(R.id.condAlimEditText).text.toString(),
                R.id.editTextNome to findViewById<EditText>(R.id.editTextNome).text.toString(),

                R.id.imageButton to findViewById<ImageButton>(R.id.imageButton).contentDescription.toString()


            )

            for ((viewId, text) in viewTextMap) {
                val view = findViewById<View>(viewId)
                if (isMouseOverView(view, x, y)) {
                    speakButtonText(text, viewId.toString())
                    return super.dispatchTouchEvent(event) // Impede verificações adicionais após o match
                }
            }

            lastSpokenButton = null
        }

        return super.dispatchTouchEvent(event)
    }

    private fun isMouseOverView(view: View, x: Float, y: Float): Boolean {
        val rect = Rect()
        view.getGlobalVisibleRect(rect)
        return rect.contains(x.toInt(), y.toInt())
    }

    private fun speakButtonText(text: String, buttonName: String) {
        if (lastSpokenButton != buttonName) {
            tts.speak(text, TextToSpeech.QUEUE_FLUSH, null, null)
            lastSpokenButton = buttonName
            Log.d("ButtonHover", "Falando: $text")
        }
    }

    override fun onInit(status: Int) {
        if (status == TextToSpeech.SUCCESS) {
            val result = tts.setLanguage(Locale("pt", "BR"))
            if (result == TextToSpeech.LANG_MISSING_DATA || result == TextToSpeech.LANG_NOT_SUPPORTED) {
                Log.e("TTS", "Idioma não suportado")
            }
        } else {
            Log.e("TTS", "Falha ao inicializar o TextToSpeech")
        }
    }

    override fun onDestroy() {
        if (tts.isSpeaking) {
            tts.stop()
        }
        tts.shutdown()
        super.onDestroy()
    }
}
