package com.example.myapplication

import android.annotation.SuppressLint
import android.app.TimePickerDialog
import android.os.Bundle
import android.view.View
import android.widget.*
import androidx.appcompat.app.AppCompatActivity
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.firestore.FirebaseFirestore
import java.text.SimpleDateFormat
import java.util.*

class PlanoAlimentarNutri : AppCompatActivity() {
    private lateinit var auth: FirebaseAuth
    private lateinit var firestore: FirebaseFirestore

    private lateinit var spinnerPatients: Spinner
    private lateinit var etMeal: EditText
    private lateinit var btnSelectTime: Button
    private lateinit var tvSelectedTime: TextView
    private lateinit var btnSaveMeal: Button
    private lateinit var recyclerView: RecyclerView

    private var selectedPatientId: String? = null
    private var selectedTime: String? = null
    private val mealList = mutableListOf<PlaneAlimentarItem>()
    private lateinit var adapter: ItemViewPlanoAdapter

    @SuppressLint("MissingInflatedId")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_plano_alimentar_nutri)

        // Inicializar Firebase
        auth = FirebaseAuth.getInstance()
        firestore = FirebaseFirestore.getInstance()

        // Referenciar os elementos da UI
        spinnerPatients = findViewById(R.id.spinnerPatients)
        etMeal = findViewById(R.id.etMeal)
        btnSelectTime = findViewById(R.id.btnSelectTime)
        tvSelectedTime = findViewById(R.id.tvSelectedTime)
        btnSaveMeal = findViewById(R.id.btnSaveMeal)
        recyclerView = findViewById(R.id.recyclerClientPlan)

        // Configurar RecyclerView
        recyclerView.layoutManager = LinearLayoutManager(this)
        adapter = ItemViewPlanoAdapter(mealList) { mealItem ->
            deleteMealFromDatabase(mealItem)
        }
        recyclerView.adapter = adapter

        // Carregar lista de pacientes
        loadPatients()

        // Configurar seleção de hora
        btnSelectTime.setOnClickListener { openTimePicker() }

        // Configurar botão para salvar plano alimentar
        btnSaveMeal.setOnClickListener { saveMealPlan() }

        // Atualizar lista ao selecionar paciente
        spinnerPatients.onItemSelectedListener = object : AdapterView.OnItemSelectedListener {
            override fun onItemSelected(parent: AdapterView<*>?, view: View?, position: Int, id: Long) {
                selectedPatientId = parent?.getItemAtPosition(position) as? String
                selectedPatientId?.let { loadPatientPlan(it) }
            }

            override fun onNothingSelected(parent: AdapterView<*>?) {
                selectedPatientId = null
            }
        }
    }

    private fun loadPatients() {
        firestore.collection("usuarios")
            .whereEqualTo("nutricionista", false) // Filtrar apenas pacientes
            .get()
            .addOnSuccessListener { querySnapshot ->
                val patients = querySnapshot.documents.mapNotNull { document ->
                    document.id to (document.getString("email") ?: "Paciente Desconhecido")
                }
                setupSpinner(patients)
            }
            .addOnFailureListener { exception ->
                Toast.makeText(this, "Erro ao carregar pacientes: ${exception.message}", Toast.LENGTH_SHORT).show()
            }
    }

    private fun setupSpinner(patients: List<Pair<String, String>>) {
        val adapter = ArrayAdapter(this, android.R.layout.simple_spinner_item, patients.map { it.second })
        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item)
        spinnerPatients.adapter = adapter

        spinnerPatients.onItemSelectedListener = object : AdapterView.OnItemSelectedListener {
            override fun onItemSelected(parent: AdapterView<*>?, view: View?, position: Int, id: Long) {
                selectedPatientId = patients[position].first
                selectedPatientId?.let { loadPatientPlan(it) }
            }

            override fun onNothingSelected(parent: AdapterView<*>?) {
                selectedPatientId = null
            }
        }
    }

    private fun openTimePicker() {
        val calendar = Calendar.getInstance()
        TimePickerDialog(
            this,
            { _, hour, minute ->
                calendar.set(Calendar.HOUR_OF_DAY, hour)
                calendar.set(Calendar.MINUTE, minute)
                val timeFormat = SimpleDateFormat("HH:mm", Locale.getDefault())
                selectedTime = timeFormat.format(calendar.time)
                tvSelectedTime.text = "Hora selecionada: $selectedTime"
            },
            calendar.get(Calendar.HOUR_OF_DAY),
            calendar.get(Calendar.MINUTE),
            true
        ).show()
    }

    private fun saveMealPlan() {
        val patientId = selectedPatientId
        val mealName = etMeal.text.toString()
        val time = selectedTime

        if (patientId.isNullOrEmpty() || mealName.isEmpty() || time.isNullOrEmpty()) {
            Toast.makeText(this, "Preencha todos os campos.", Toast.LENGTH_SHORT).show()
            return
        }

        val mealData = mapOf(
            "refeicao" to mealName,
            "hora" to time
        )

        firestore.collection("atividades").document(patientId).collection("planoAlimentar")
            .document(time)
            .set(mealData)
            .addOnSuccessListener {
                Toast.makeText(this, "Plano alimentar salvo com sucesso.", Toast.LENGTH_SHORT).show()
                etMeal.text.clear()
                tvSelectedTime.text = "Hora selecionada: Nenhuma"
                loadPatientPlan(patientId) // Atualizar lista

                // Salvar no histórico
                saveToHistory(patientId, "Adicionado plano alimentar: '$mealName' às $time")
            }
            .addOnFailureListener { exception ->
                Toast.makeText(this, "Erro ao salvar plano alimentar: ${exception.message}", Toast.LENGTH_SHORT).show()
            }
    }

    private fun loadPatientPlan(patientId: String) {
        firestore.collection("atividades").document(patientId).collection("planoAlimentar")
            .get()
            .addOnSuccessListener { querySnapshot ->
                mealList.clear()
                mealList.addAll(
                    querySnapshot.documents.mapNotNull { document ->
                        val mealName = document.getString("refeicao") ?: return@mapNotNull null
                        val time = document.getString("hora") ?: "Sem horário"
                        PlaneAlimentarItem(mealName, time)
                    }
                )
                adapter.notifyDataSetChanged()
            }
            .addOnFailureListener { exception ->
                Toast.makeText(this, "Erro ao carregar plano do paciente: ${exception.message}", Toast.LENGTH_SHORT).show()
            }
    }

    private fun deleteMealFromDatabase(mealItem: PlaneAlimentarItem) {
        val patientId = selectedPatientId ?: return
        firestore.collection("atividades").document(patientId).collection("planoAlimentar")
            .whereEqualTo("refeicao", mealItem.mealName)
            .whereEqualTo("hora", mealItem.mealTime)
            .get()
            .addOnSuccessListener { querySnapshot ->
                for (document in querySnapshot.documents) {
                    document.reference.delete()
                        .addOnSuccessListener {
                            mealList.remove(mealItem)
                            adapter.notifyDataSetChanged()
                            Toast.makeText(this, "Refeição removida.", Toast.LENGTH_SHORT).show()

                            // Salvar no histórico
                            saveToHistory(patientId, "Removido plano alimentar: '${mealItem.mealName}' às ${mealItem.mealTime} pelo Nutricionista")
                        }
                        .addOnFailureListener { exception ->
                            Toast.makeText(this, "Erro ao remover refeição: ${exception.message}", Toast.LENGTH_SHORT).show()
                        }
                }
            }
            .addOnFailureListener { exception ->
                Toast.makeText(this, "Erro ao encontrar refeição: ${exception.message}", Toast.LENGTH_SHORT).show()
            }
    }

    private fun saveToHistory(patientId: String, actionDescription: String) {
        val historyData = mapOf(
            "descricao" to actionDescription,
            "timestamp" to System.currentTimeMillis()
        )

        firestore.collection("usuarios").document(patientId).collection("historico")
            .add(historyData)
            .addOnFailureListener { exception ->
                Toast.makeText(this, "Erro ao registrar histórico: ${exception.message}", Toast.LENGTH_SHORT).show()
            }
    }
}
