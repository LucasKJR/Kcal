package com.example.myapplication

import android.Manifest
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.net.Uri
import android.os.Bundle
import android.provider.MediaStore
import android.util.Base64
import android.util.Log
import android.widget.*
import androidx.appcompat.app.AppCompatActivity
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat
import androidx.core.content.FileProvider
import androidx.lifecycle.lifecycleScope
import com.google.ai.client.generativeai.GenerativeModel
import com.google.ai.client.generativeai.type.content
import kotlinx.coroutines.launch
import java.io.ByteArrayOutputStream
import java.io.File
import java.io.IOException
import java.io.InputStream

class GeminiMenu : AppCompatActivity() {

    private val apiKey = "AIzaSyAqKk3AYE_Et0tA2S6w0VhGAjWsK1FVxHc"
    private lateinit var geminiResp: TextView
    private lateinit var selectImageButton: Button
    private lateinit var captureImageButton: Button
    private lateinit var selectedImageView: ImageView
    private lateinit var sendButton: Button
    private lateinit var btnMenuPrincipal: ImageView
    private lateinit var btnConfig: ImageView
    private lateinit var btnMicrophone: ImageView
    private lateinit var btnCamera: ImageView
    private var selectedImageUri: Uri? = null
    private lateinit var photoFile: File
    private lateinit var ttsManager: TTSManager

    override fun onCreate(savedInstanceState: Bundle?) {
        ttsManager = TTSManager(this)

        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_gemini_menu)

        // Inicialização dos componentes
        geminiResp = findViewById(R.id.geminiResp)
        selectImageButton = findViewById(R.id.selectImageButton)
        captureImageButton = findViewById(R.id.captureImageButton)
        selectedImageView = findViewById(R.id.selectedImageView)
        sendButton = findViewById(R.id.sendbutton)
        btnMenuPrincipal = findViewById(R.id.btnMenuPrincipal)
        btnConfig = findViewById(R.id.btnConfig)
        btnMicrophone = findViewById(R.id.btnMicrophone)
        btnCamera = findViewById(R.id.btnCamera)

        // Configuração dos botões da navbar
        btnCamera.setOnClickListener {
            finish()
            val intent = Intent(this, GeminiMenu::class.java)
            startActivity(intent)
        }

        btnConfig.setOnClickListener {
            val intent = Intent(this, Configuracoes::class.java)
            startActivity(intent)
        }
        btnMicrophone.setOnClickListener {
            ttsManager.speak("Na Tela de IA você pode selecionar imagens e tirar fotos para saber a quantidade de calorias do alimento ou produto na foto.")
            Toast.makeText(this, "Text-to-Speech acionado.", Toast.LENGTH_SHORT).show()

        }

        btnMenuPrincipal.setOnClickListener {
            finish()
        }

        // Botão para selecionar imagem da galeria
        selectImageButton.setOnClickListener {
            val intent = Intent(Intent.ACTION_PICK, MediaStore.Images.Media.EXTERNAL_CONTENT_URI)
            startActivityForResult(intent, REQUEST_IMAGE_SELECT)
        }

        // Botão para capturar imagem com a câmera
        captureImageButton.setOnClickListener {
            checkAndRequestCameraPermission()
        }

        // Botão para enviar requisição
        sendButton.setOnClickListener {
            selectedImageUri?.let { uri ->
                lifecycleScope.launch {
                    processImageAndSend(uri)
                }
            } ?: run {
                Toast.makeText(this, "Selecione ou capture uma imagem antes de enviar.", Toast.LENGTH_SHORT).show()
            }
        }
    }

    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == REQUEST_IMAGE_SELECT && resultCode == RESULT_OK) { // Galeria
            selectedImageUri = data?.data
            selectedImageView.setImageURI(selectedImageUri)
        } else if (requestCode == REQUEST_IMAGE_CAPTURE && resultCode == RESULT_OK) { // Câmera
            selectedImageUri = Uri.fromFile(photoFile)
            selectedImageView.setImageURI(selectedImageUri)
        }
    }

    private fun checkAndRequestCameraPermission() {
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.CAMERA) != PackageManager.PERMISSION_GRANTED) {
            ActivityCompat.requestPermissions(this, arrayOf(Manifest.permission.CAMERA), CAMERA_PERMISSION_REQUEST_CODE)
        } else {
            dispatchTakePictureIntent()
        }
    }

    private fun dispatchTakePictureIntent() {
        val intent = Intent(MediaStore.ACTION_IMAGE_CAPTURE)
        if (intent.resolveActivity(packageManager) != null) {
            try {
                photoFile = createImageFile()
                val photoURI: Uri = FileProvider.getUriForFile(
                    this,
                    "${packageName}.fileprovider",
                    photoFile
                )
                intent.putExtra(MediaStore.EXTRA_OUTPUT, photoURI)
                startActivityForResult(intent, REQUEST_IMAGE_CAPTURE)
            } catch (e: IOException) {
                Toast.makeText(this, "Erro ao criar arquivo de imagem.", Toast.LENGTH_SHORT).show()
                Log.e("Erro", "Erro ao criar arquivo de imagem: ${e.message}")
            }
        }
    }

    private fun createImageFile(): File {
        val storageDir = externalCacheDir
        return File.createTempFile("JPEG_${System.currentTimeMillis()}_", ".jpg", storageDir)
    }

    private suspend fun processImageAndSend(uri: Uri) {
        val bitmap = getBitmapFromUri(uri)
        bitmap?.let {
            val generativeModel = GenerativeModel(
                modelName = "gemini-1.5-flash-latest",
                apiKey = apiKey
            )

            val inputContent = content {
                image(it)
                text("Analise e utilizando sua visão computacional gere uma estimativa de quanteidade de cada comida na foto e estime a quantidade de calorias,e responda somente a quantidade de calorias,não responda NADA ALEM DA QUANTIDADE DE CALORIAS,caso seja um produto pesquise pelas calorias do produto e responda somente AS QUANTIDADES DE CALORIAS.")            }

            try {
                // Mostra um Toast indicando que o processamento foi iniciado
                runOnUiThread {
                    Toast.makeText(this, "Processando imagem, por favor aguarde...", Toast.LENGTH_SHORT).show()
                }

                val response = generativeModel.generateContent(inputContent)

                // Mostra um Toast com o sucesso do processamento
                runOnUiThread {
                    Toast.makeText(this, "Imagem processada com sucesso!", Toast.LENGTH_SHORT).show()
                }

                geminiResp.text = response.text ?: "Sem resposta do servidor."
                Log.d("Gemini Response", response.text ?: "Nenhuma resposta.")
            } catch (e: Exception) {
                // Mostra um Toast indicando falha no processamento
                runOnUiThread {
                    Toast.makeText(this, "Erro ao processar a imagem: ${e.message}", Toast.LENGTH_SHORT).show()
                }
                geminiResp.text = "Erro ao processar a imagem: ${e.message}"
                Log.e("Erro Gemini", e.message ?: "Erro desconhecido")
            }
        } ?: run {
            // Mostra um Toast indicando falha no carregamento da imagem
            runOnUiThread {
                Toast.makeText(this, "Erro ao carregar a imagem.", Toast.LENGTH_SHORT).show()
            }
            geminiResp.text = "Erro ao carregar a imagem."
        }
    }


    private fun getBitmapFromUri(uri: Uri): Bitmap? {
        return try {
            val inputStream: InputStream? = contentResolver.openInputStream(uri)
            BitmapFactory.decodeStream(inputStream)
        } catch (e: Exception) {
            Log.e("Erro", "Erro ao converter URI para Bitmap: ${e.message}")
            null
        }
    }

    private fun bitmapToBase64(bitmap: Bitmap): String {
        val outputStream = ByteArrayOutputStream()
        bitmap.compress(Bitmap.CompressFormat.JPEG, 100, outputStream)
        val byteArray = outputStream.toByteArray()
        return Base64.encodeToString(byteArray, Base64.NO_WRAP)
    }

    override fun onRequestPermissionsResult(
        requestCode: Int,
        permissions: Array<out String>,
        grantResults: IntArray
    ) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        if (requestCode == CAMERA_PERMISSION_REQUEST_CODE) {
            if (grantResults.isNotEmpty() && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                dispatchTakePictureIntent()
            } else {
                Toast.makeText(this, "Permissão para usar a câmera foi negada.", Toast.LENGTH_SHORT).show()
            }
        }
    }

    companion object {
        private const val REQUEST_IMAGE_CAPTURE = 101
        private const val REQUEST_IMAGE_SELECT = 100
        private const val CAMERA_PERMISSION_REQUEST_CODE = 102
    }
    override fun onDestroy() {
        super.onDestroy()
        ttsManager.shutdown() // Libera recursos do TTS
    }
}
