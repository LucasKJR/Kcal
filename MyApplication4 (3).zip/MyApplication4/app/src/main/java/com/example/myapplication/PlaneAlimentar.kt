package com.example.myapplication

import android.annotation.SuppressLint
import android.content.Intent
import android.os.Bundle
import android.widget.ImageView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.firestore.FirebaseFirestore

data class PlaneAlimentarItem(val mealName: String, val mealTime: String)

class PlaneAlimentar : AppCompatActivity() {
    private lateinit var recy: RecyclerView
    private lateinit var auth: FirebaseAuth
    private lateinit var firestore: FirebaseFirestore
    private lateinit var ttsManager: TTSManager

    @SuppressLint("MissingInflatedId")
    override fun onCreate(savedInstanceState: Bundle?) {
        ttsManager = TTSManager(this)

        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_plane_alimentar)

        val btnMenuPrincipal = findViewById<ImageView>(R.id.btnMenuPrincipal)
        val btnConfig = findViewById<ImageView>(R.id.btnConfig)
        val btnMicrophone = findViewById<ImageView>(R.id.btnMicrophone)
        val btnCamera = findViewById<ImageView>(R.id.btnCamera)

        btnMenuPrincipal.setOnClickListener { finish() }

        btnConfig.setOnClickListener {
            val intent = Intent(this, Configuracoes::class.java)
            startActivity(intent)
        }

        btnMicrophone.setOnClickListener {
            ttsManager.speak("Nessa tela de Plano Alimentar, você tem acesso ao plano alimentar criado pelo seu nutricionista.")
            Toast.makeText(this, "Text-to-Speech acionado.", Toast.LENGTH_SHORT).show()
        }

        btnCamera.setOnClickListener {
            finish()
            val intent = Intent(this, GeminiMenu::class.java)
            startActivity(intent)
        }

        // Inicialização do botão de voltar
        val btnBack = findViewById<ImageView>(R.id.btnBack)
        btnBack.setOnClickListener { finish() }

        recy = findViewById(R.id.recy)

        // Inicializa Firebase
        auth = FirebaseAuth.getInstance()
        firestore = FirebaseFirestore.getInstance()

        // Carregar informações do plano alimentar
        loadPlanoAlimentar()
    }

    private fun loadPlanoAlimentar() {
        val userId = auth.currentUser?.uid ?: return
        val collectionRef = firestore.collection("atividades")
            .document(userId)
            .collection("planoAlimentar")

        val list = mutableListOf<PlaneAlimentarItem>()

        collectionRef.get()
            .addOnSuccessListener { querySnapshot ->
                if (!querySnapshot.isEmpty) {
                    querySnapshot.documents.forEach { document ->
                        val refeicao = document.getString("refeicao") ?: "Sem informação"
                        val hora = document.getString("hora") ?: "Sem horário"
                        list.add(PlaneAlimentarItem(refeicao, hora))
                    }

                    // Atualiza o RecyclerView com os itens carregados
                    val adapter = ItemViewPlanoAdapter(list) { itemToDelete ->
                        deletePlanoAlimentarItem(userId, itemToDelete, list)
                    }
                    recy.layoutManager = LinearLayoutManager(this)
                    recy.adapter = adapter
                } else {
                    Toast.makeText(this, "Nenhum plano alimentar encontrado", Toast.LENGTH_SHORT).show()
                }
            }
            .addOnFailureListener { exception ->
                Toast.makeText(this, "Erro ao carregar plano alimentar: ${exception.message}", Toast.LENGTH_SHORT).show()
            }
    }

    private fun deletePlanoAlimentarItem(
        userId: String,
        itemToDelete: PlaneAlimentarItem,
        list: MutableList<PlaneAlimentarItem>
    ) {
        val collectionRef = firestore.collection("atividades")
            .document(userId)
            .collection("planoAlimentar")

        // Encontra o documento correspondente no Firebase
        collectionRef.whereEqualTo("refeicao", itemToDelete.mealName)
            .whereEqualTo("hora", itemToDelete.mealTime)
            .get()
            .addOnSuccessListener { querySnapshot ->
                if (!querySnapshot.isEmpty) {
                    val documentId = querySnapshot.documents.first().id
                    collectionRef.document(documentId)
                        .delete()
                        .addOnSuccessListener {
                            list.remove(itemToDelete)
                            recy.adapter?.notifyDataSetChanged()
                            Toast.makeText(this, "Item excluído com sucesso", Toast.LENGTH_SHORT).show()

                            // Registrar no histórico
                            saveToHistory(userId, itemToDelete)
                        }
                        .addOnFailureListener { exception ->
                            Toast.makeText(this, "Erro ao excluir item: ${exception.message}", Toast.LENGTH_SHORT).show()
                        }
                }
            }
            .addOnFailureListener { exception ->
                Toast.makeText(this, "Erro ao encontrar item: ${exception.message}", Toast.LENGTH_SHORT).show()
            }
    }

    private fun saveToHistory(userId: String, item: PlaneAlimentarItem) {
        val timestamp = System.currentTimeMillis()
        val historyData = mapOf(
            "refeicao" to item.mealName,
            "hora" to item.mealTime,
            "removidoPor" to "Cliente",
            "timestamp" to timestamp
        )

        firestore.collection("atividades")
            .document(userId)
            .collection("planoAlimentarRemovidos")
            .add(historyData)
            .addOnFailureListener { exception ->
                Toast.makeText(this, "Erro ao registrar no histórico: ${exception.message}", Toast.LENGTH_SHORT).show()
            }
    }

    override fun onDestroy() {
        super.onDestroy()
        ttsManager.shutdown() // Libera recursos do TTS
    }
}
