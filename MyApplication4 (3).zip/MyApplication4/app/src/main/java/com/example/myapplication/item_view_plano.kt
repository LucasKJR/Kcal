package com.example.myapplication

import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ImageButton
import android.widget.TextView
import androidx.core.content.ContextCompat
import androidx.recyclerview.widget.RecyclerView
class ItemViewPlanoAdapter(
    private val list: MutableList<PlaneAlimentarItem>,
    private val onDeleteClick: (PlaneAlimentarItem) -> Unit
) : RecyclerView.Adapter<ItemViewPlanoAdapter.MyViewHolder>() {

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): MyViewHolder {
        val view = LayoutInflater.from(parent.context).inflate(R.layout.item_view_plano, parent, false)
        return MyViewHolder(view)
    }

    override fun onBindViewHolder(holder: MyViewHolder, position: Int) {
        val currentItem = list[position]
        holder.textViewMeal.text = currentItem.mealName
        holder.textViewTime.text = currentItem.mealTime

        // Configuração do botão de exclusão
        holder.btnDelete.setOnClickListener {
            onDeleteClick(currentItem)
        }

        // Alternância de cores das linhas com base na posição
        if (position % 2 == 0) {
            holder.itemView.setBackgroundColor(
                ContextCompat.getColor(holder.itemView.context, R.color.light_pink)
            )
        } else {
            holder.itemView.setBackgroundColor(
                ContextCompat.getColor(holder.itemView.context, R.color.white)
            )
        }
    }

    override fun getItemCount(): Int = list.size

    class MyViewHolder(itemView: View) : RecyclerView.ViewHolder(itemView) {
        val textViewMeal: TextView = itemView.findViewById(R.id.tv_meal_name)
        val textViewTime: TextView = itemView.findViewById(R.id.tv_meal_time)
        val btnDelete: ImageButton = itemView.findViewById(R.id.btn_delete)
    }
}
