package com.example.myapplication

import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView

class DiarioAdapter(private val list: List<DiarioItem>) :
    RecyclerView.Adapter<DiarioAdapter.MyViewHolder>() {

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): MyViewHolder {
        val view = LayoutInflater.from(parent.context)
            .inflate(R.layout.item_view_diario, parent, false)
        return MyViewHolder(view)
    }

    override fun onBindViewHolder(holder: MyViewHolder, position: Int) {
        val currentItem = list[position]
        holder.atividade.text = currentItem.atividade
        holder.dataHora.text = currentItem.dataHora
    }

    override fun getItemCount(): Int = list.size

    class MyViewHolder(itemView: View) : RecyclerView.ViewHolder(itemView) {
        val atividade: TextView = itemView.findViewById(R.id.tv_meal_name)
        val dataHora: TextView = itemView.findViewById(R.id.tv_meal_time)
    }
}
