package com.example.myapplication

import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.widget.Button
import android.widget.ImageView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
private lateinit var ttsManager: TTSManager

class Suporte : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        ttsManager = TTSManager(this)

        val btnMicrophone = findViewById<ImageView>(R.id.btnMicrophone)
        val btnCamera = findViewById<ImageView>(R.id.btnCamera)
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_suporte)

        findViewById<ImageView>(R.id.btnMenuPrincipal).setOnClickListener {
            finish() // Retorna à tela anterior
        }

        findViewById<ImageView>(R.id.btnConfig).setOnClickListener {
            val intent = Intent(this, Configuracoes::class.java)
            startActivity(intent)
        }

        findViewById<ImageView>(R.id.btnMicrophone).setOnClickListener {
            ttsManager.speak("Na tela de Suporte, Você pode ligar para suporte ou para a central, caso precise de ajuda com o aplicativo.")
            Toast.makeText(this, "Text-to-Speech acionado.", Toast.LENGTH_SHORT).show()
        }

        findViewById<ImageView>(R.id.btnCamera).setOnClickListener {
            finish()
            val intent = Intent(this, GeminiMenu::class.java)
            startActivity(intent)
        }



        // Ligar para Creusa
        findViewById<Button>(R.id.btn_call_creusa).setOnClickListener {
            startCall("tel:21969778772")
        }

        // Ligar para Central
        findViewById<Button>(R.id.btn_call_central).setOnClickListener {
            startCall("tel:21969778772")
        }
    }

    private fun startCall(phoneNumber: String) {
        val intent = Intent(Intent.ACTION_DIAL)
        intent.data = Uri.parse(phoneNumber)
        startActivity(intent)
    }
    override fun onDestroy() {
        super.onDestroy()
        ttsManager.shutdown() // Libera recursos do TTS
    }
}
