package com.example.myapplication

import ItemViewReceitasAdapter
import ReceitaItem
import android.content.Intent
import android.os.Bundle
import android.widget.ImageView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView

class Receitas : AppCompatActivity() {
    private lateinit var recyclerView: RecyclerView
    private lateinit var adapter: ItemViewReceitasAdapter
    private lateinit var ttsManager: TTSManager

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_receitas)

        // Inicializar TTS
        ttsManager = TTSManager(this)

        // Inicializar RecyclerView
        recyclerView = findViewById(R.id.recycler_receitas)
        setupRecyclerView()

        // Configurar botões da Navbar
        setupNavbar()

        // Configurar botão de voltar
        val btnBack = findViewById<ImageView>(R.id.btnBack)
        btnBack.setOnClickListener { finish() }
    }

    private fun setupNavbar() {
        val btnMenuPrincipal = findViewById<ImageView>(R.id.btnMenuPrincipal)
        val btnConfig = findViewById<ImageView>(R.id.btnConfig)
        val btnCamera = findViewById<ImageView>(R.id.btnCamera)
        val btnMicrophone = findViewById<ImageView>(R.id.btnMicrophone)

        btnMenuPrincipal.setOnClickListener {
            finish()
        }

        btnConfig.setOnClickListener {
            val intent = Intent(this, Configuracoes::class.java)
            startActivity(intent)
        }

        btnCamera.setOnClickListener {
            finish()
            val intent = Intent(this, GeminiMenu::class.java)
            startActivity(intent)
        }

        btnMicrophone.setOnClickListener {
            ttsManager.speak("Na tela de receitas, você pode ouvir os ingredientes das receitas.")
            Toast.makeText(this, "Text-to-Speech acionado.", Toast.LENGTH_SHORT).show()
        }
    }

    private fun setupRecyclerView() {
        val receitas = listOf(
            ReceitaItem("Arroz cremoso", "• Creme de leite\n• Arroz"),
            ReceitaItem("Macarrão ao molho branco", "• Macarrão\n• Molho branco"),
            ReceitaItem("Frango grelhado", "• Filé de frango\n• Tempero a gosto")
        )

        adapter = ItemViewReceitasAdapter(this, receitas)
        recyclerView.layoutManager = LinearLayoutManager(this)
        recyclerView.adapter = adapter
    }

    override fun onDestroy() {
        super.onDestroy()
        ttsManager.shutdown() // Finalizar o Text-to-Speech ao destruir a Activity
    }
}
