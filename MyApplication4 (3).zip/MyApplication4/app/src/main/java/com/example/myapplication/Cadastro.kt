package com.example.myapplication

import android.annotation.SuppressLint
import android.content.Intent
import android.os.Bundle
import android.view.View
import android.widget.Button
import android.widget.CheckBox
import android.widget.EditText
import android.widget.TextView
import android.widget.Toast
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AppCompatActivity
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.firestore.FirebaseFirestore

class Cadastro : AppCompatActivity() {

    private lateinit var firebaseAuth: FirebaseAuth
    private lateinit var firestore: FirebaseFirestore

    @SuppressLint("MissingInflatedId")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContentView(R.layout.activity_cadastro)

        // Inicializar FirebaseAuth e Firestore
        firebaseAuth = FirebaseAuth.getInstance()
        firestore = FirebaseFirestore.getInstance()

        // Referências aos IDs do XML
        val emailEditText: EditText = findViewById(R.id.etEmail)
        val passwordEditText: EditText = findViewById(R.id.etPassword)
        val confirmPasswordEditText: EditText = findViewById(R.id.etConfirmPassword)
        val checkboxNutricionista: CheckBox = findViewById(R.id.checkboxNutricionista)
        val crnEditText: EditText = findViewById(R.id.etCRN)
        val btnSubmitRegister: Button = findViewById(R.id.btnSubmitRegister)
        val labelCadastro: TextView = findViewById(R.id.labelCadastro)

        // Exibir campo CRN ao marcar o CheckBox
        checkboxNutricionista.setOnCheckedChangeListener { _, isChecked ->
            crnEditText.visibility = if (isChecked) View.VISIBLE else View.GONE
        }

        // Lidar com o clique no botão "Cadastrar"
        btnSubmitRegister.setOnClickListener {
            val email = emailEditText.text.toString()
            val password = passwordEditText.text.toString()
            val confirmPassword = confirmPasswordEditText.text.toString()
            val isNutricionista = checkboxNutricionista.isChecked
            val crn = crnEditText.text.toString()

            if (email.isEmpty() || password.isEmpty() || confirmPassword.isEmpty()) {
                showToast("Preencha todos os campos")
            } else if (password != confirmPassword) {
                showToast("As senhas não coincidem")
            } else if (isNutricionista && crn.isEmpty()) {
                showToast("Informe o CRN")
            } else {
                cadastrarUsuario(email, password, isNutricionista, crn)
            }
        }

        // Redirecionar para a tela de login
        labelCadastro.setOnClickListener {
            val intent = Intent(this, Login::class.java)
            startActivity(intent)
        }
    }

    private fun cadastrarUsuario(email: String, password: String, isNutricionista: Boolean, crn: String) {
        firebaseAuth.createUserWithEmailAndPassword(email, password)
            .addOnCompleteListener { task ->
                if (task.isSuccessful) {
                    val userId = firebaseAuth.currentUser?.uid
                    if (userId != null) {
                        salvarUsuarioNoFirestore(userId, email, isNutricionista, crn)
                    } else {
                        showToast("Erro ao obter ID do usuário.")
                    }
                } else {
                    task.exception?.message?.let {
                        showToast("Erro ao cadastrar usuário: $it")
                    }
                }
            }
    }

    private fun salvarUsuarioNoFirestore(userId: String, email: String, isNutricionista: Boolean, crn: String) {
        val user = mutableMapOf(
            "email" to email,
            "nutricionista" to isNutricionista
        )
        if (isNutricionista) {
            user["CRN"] = crn
        }

        firestore.collection("usuarios").document(userId)
            .set(user)
            .addOnSuccessListener {
                showToast("Cadastro realizado com sucesso!")
                redirecionarParaLogin()
            }
            .addOnFailureListener { exception ->
                showToast("Erro ao salvar dados no Firestore: ${exception.message}")
            }
    }

    private fun redirecionarParaLogin() {
        val intent = Intent(this, Login::class.java)
        startActivity(intent)
        finish()
    }

    private fun showToast(message: String) {
        Toast.makeText(this@Cadastro, message, Toast.LENGTH_LONG).show()
    }
}
