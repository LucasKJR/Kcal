import android.annotation.SuppressLint
import android.content.Intent
import android.os.Bundle
import android.widget.LinearLayout
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat.startActivity
import com.example.myapplication.Configuracoes
import com.example.myapplication.R

class MainActivityB : AppCompatActivity() {

    private lateinit var btnPerfil: LinearLayout
    private lateinit var btnDiario: LinearLayout
    private lateinit var btnListaCompra: LinearLayout
    private lateinit var btnHistorico: LinearLayout
    private lateinit var btnPlanoAlimentar: LinearLayout
    private lateinit var btnReceitas: LinearLayout

    @SuppressLint("MissingInflatedId")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContentView(R.layout.activity_main_b)

        // Alterando para LinearLayout ao invés de Button
        btnDiario = findViewById(R.id.btnDiario)
        btnListaCompra = findViewById(R.id.btnListaCompra)
        btnHistorico = findViewById(R.id.btnHistorico)
        btnPlanoAlimentar = findViewById(R.id.btnPlano)
        btnReceitas = findViewById(R.id.btnReceitas)
        btnPerfil = findViewById(R.id.btnMenu)

        btnPerfil.setOnClickListener {
            val intent = Intent(this, Configuracoes::class.java)
            startActivity(intent)
        }

        // Adicione listeners para os outros botões, se necessário
        btnDiario.setOnClickListener {
            // Ação para o botão Diario
        }

        btnListaCompra.setOnClickListener {
            // Ação para o botão Lista de Compras
        }

        // ... e assim por diante para os outros botões ...
    }
}
