    package com.example.myapplication

    import android.annotation.SuppressLint
    import android.content.Intent
    import android.graphics.Rect
    import android.os.Build
    import android.os.Bundle
    import android.speech.tts.TextToSpeech
    import android.util.Log
    import android.view.MotionEvent
    import android.view.View
    import android.widget.Button
    import android.widget.TextView
    import androidx.annotation.RequiresApi
    import androidx.appcompat.app.AppCompatActivity
    import java.util.*

    class Menu1 : AppCompatActivity(), TextToSpeech.OnInitListener {

        private lateinit var menuBotao: Button
        private lateinit var suporteBotao: Button
        private lateinit var configBotao: Button
        private lateinit var logo: TextView

        private lateinit var tts: TextToSpeech
        private var lastSpokenButton: String? = null // Evitar repetição desnecessária de áudio

        @RequiresApi(Build.VERSION_CODES.R)
        @SuppressLint("MissingInflatedId", "ClickableViewAccessibility", "SuspiciousIndentation")
        override fun onCreate(savedInstanceState: Bundle?) {
            super.onCreate(savedInstanceState)
            setContentView(R.layout.activity_main)

            // Inicializando o Text-to-Speech
            tts = TextToSpeech(this, this)


            // Referenciando os itens a lidos existentes no layout

            //===================================ITENS A DECLARADOS
            menuBotao = findViewById(R.id.btnMenu)
            suporteBotao = findViewById(R.id.btnSuporte)
            configBotao = findViewById(R.id.btnConfig)
            logo = findViewById(R.id.logoTextview)

                //====================================================================================NAVEGAÇÃO DA PAGINA
                menuBotao.setOnClickListener {
                val intent = Intent(this, MenuSecundario::class.java)
                startActivity(intent)
            }
            suporteBotao.setOnClickListener {
                val ntent = Intent(this, Suporte::class.java)
                startActivity(ntent)
            }

            configBotao.setOnClickListener {
                val ntent = Intent(this, suporteTela::class.java)
                startActivity(ntent)
            }
        }

        override fun dispatchTouchEvent(event: MotionEvent?): Boolean {
            event?.let {
                val x = it.rawX
                val y = it.rawY

                // Logar as coordenadas X e Y do mouse/dedo
                Log.d("TouchCoords", "Coordenadas X: $x, Y: $y")

                // ============================================================== VETOR DOS INTENS INTERATIVOS
                val viewTextMap = mapOf(
                    R.id.btnMenu to findViewById<Button>(R.id.btnMenu).text.toString(),
                    R.id.btnSuporte to findViewById<Button>(R.id.btnSuporte).text.toString(),
                    R.id.btnConfig to findViewById<Button>(R.id.btnConfig).text.toString(),
                    R.id.logoTextview to findViewById<TextView>(R.id.logoTextview).text.toString()


                )

                for ((viewId, text) in viewTextMap) {
                    val view = findViewById<View>(viewId)
                    if (isMouseOverView(view, x, y)) {
                        speakButtonText(text, viewId.toString())
                        return super.dispatchTouchEvent(event) // Impede verificações adicionais após o match
                    }
                }

                lastSpokenButton = null // Resetar para evitar repetição quando sair de um botão
            }

            return super.dispatchTouchEvent(event)
        }

        // Verificar se o mouse/dedo está sobre uma view
        private fun isMouseOverView(view: View, x: Float, y: Float): Boolean {
            val rect = Rect()
            view.getGlobalVisibleRect(rect)
            return rect.contains(x.toInt(), y.toInt())
        }


        // Falar o texto do botão usando TTS
        private fun speakButtonText(text: String, buttonName: String) {
            // Falar apenas se não tiver sido falado recentemente para evitar repetição desnecessária
            if (lastSpokenButton != buttonName) {
                tts.speak(text, TextToSpeech.QUEUE_FLUSH, null, null)
                lastSpokenButton = buttonName
                Log.d("ButtonHover", "Falando: $text")
            }
        }

        // Inicializar o Text-to-Speech
        override fun onInit(status: Int) {
            if (status == TextToSpeech.SUCCESS) {
                // Configurar o idioma do TTS
                val result = tts.setLanguage(Locale("pt", "BR"))
                if (result == TextToSpeech.LANG_MISSING_DATA || result == TextToSpeech.LANG_NOT_SUPPORTED) {
                    Log.e("TTS", "Idioma não suportado")
                }
            } else {
                Log.e("TTS", "Falha ao inicializar o TextToSpeech")
            }
        }

        // Desligar o TTS quando a activity for destruída
        override fun onDestroy() {
            if (tts.isSpeaking) {
                tts.stop()
            }
            tts.shutdown()
            super.onDestroy()
        }
    }
