package com.example.myapplication

import android.annotation.SuppressLint
import android.content.Intent
import android.os.Bundle
import android.widget.Button
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat

class MenuSecundario : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContentView(R.layout.activity_menu_secundario)
        findViewById<Button>(R.id.btnDiario).setOnClickListener {
            val intent = Intent(this, Diario::class.java)
            startActivity(intent)
        }
        findViewById<Button>(R.id.btnOutros).setOnClickListener {
            val intent = Intent(this, MenuPrincipal::class.java)
            startActivity(intent)
        }
        findViewById<Button>(R.id.btnCamera).setOnClickListener {
            val intent = Intent(this, InfoAlimento::class.java)
            startActivity(intent)
        }
        findViewById<Button>(R.id.button9).setOnClickListener {
            val intent = Intent(this, Menu1::class.java)
            startActivity(intent)
        }


    }
}