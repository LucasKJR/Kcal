package com.example.myapplication

import android.content.Intent
import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import android.widget.ImageView
import android.widget.Toast
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.firestore.FirebaseFirestore

class ListaCompra : AppCompatActivity() {
    private lateinit var recy: RecyclerView
    private lateinit var firestore: FirebaseFirestore
    private lateinit var auth: FirebaseAuth
    private val itemList = mutableListOf<String>()
    private lateinit var adapter: ItemAdapter
    private lateinit var ttsManager: TTSManager

    override fun onCreate(savedInstanceState: Bundle?) {
        ttsManager = TTSManager(this)

        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_lista_compra)

        // Inicializar Firebase
        auth = FirebaseAuth.getInstance()
        firestore = FirebaseFirestore.getInstance()

        // Inicializar RecyclerView
        recy = findViewById(R.id.recy)
        adapter = ItemAdapter(itemList) { item -> confirmItem(item) }
        recy.layoutManager = LinearLayoutManager(this)
        recy.adapter = adapter

        // Carregar a lista inicial
        loadItemsFromDatabase()

        // Botão de adicionar item
        findViewById<Button>(R.id.btnAddItem).setOnClickListener { showAddItemDialog() }

        // Configuração do botão de voltar
        val btnBack = findViewById<ImageView>(R.id.btnBack)
        btnBack.setOnClickListener { finish() }

        // Configuração da Navbar
        setupNavbar()
    }

    private fun setupNavbar() {
        val btnMenuPrincipal = findViewById<ImageView>(R.id.btnMenuPrincipal)
        val btnConfig = findViewById<ImageView>(R.id.btnConfig)
        val btnMicrophone = findViewById<ImageView>(R.id.btnMicrophone)
        val btnCamera = findViewById<ImageView>(R.id.btnCamera)

        btnMenuPrincipal.setOnClickListener {
            finish()
            startActivity(Intent(this, MenuPrincipal::class.java))
        }

        btnConfig.setOnClickListener {
            startActivity(Intent(this, Configuracoes::class.java))
        }

        btnMicrophone.setOnClickListener {
            ttsManager.speak("Na tela de Lista de Compra, você pode gerenciar os itens da sua lista, adicionar novos itens e removê-los.")
        }

        btnCamera.setOnClickListener {
            finish()
            startActivity(Intent(this, GeminiMenu::class.java))
        }
    }

    private fun loadItemsFromDatabase() {
        val userId = auth.currentUser?.uid ?: return
        firestore.collection("usuarios").document(userId).collection("listaCompra")
            .get()
            .addOnSuccessListener { querySnapshot ->
                itemList.clear()
                for (document in querySnapshot) {
                    val item = document.getString("item")
                    if (item != null) {
                        itemList.add(item)
                    }
                }
                adapter.notifyDataSetChanged()
            }
            .addOnFailureListener { exception ->
                Toast.makeText(this, "Erro ao carregar lista: ${exception.message}", Toast.LENGTH_SHORT).show()
            }
    }

    private fun showAddItemDialog() {
        val dialogView = layoutInflater.inflate(R.layout.add_item_dialog, null)
        val editTextItem = dialogView.findViewById<EditText>(R.id.etItem)

        AlertDialog.Builder(this)
            .setTitle("Adicionar Item")
            .setView(dialogView)
            .setPositiveButton("Salvar") { _, _ ->
                val itemName = editTextItem.text.toString().trim()
                if (itemName.isNotBlank()) {
                    saveItemToDatabase(itemName)
                } else {
                    Toast.makeText(this, "Digite um nome válido para o item", Toast.LENGTH_SHORT).show()
                }
            }
            .setNegativeButton("Cancelar", null)
            .show()
    }

    private fun saveItemToDatabase(itemName: String) {
        val userId = auth.currentUser?.uid ?: return
        val itemData = mapOf("item" to itemName, "timestamp" to System.currentTimeMillis())

        firestore.collection("usuarios").document(userId).collection("listaCompra")
            .add(itemData)
            .addOnSuccessListener {
                itemList.add(itemName)
                adapter.notifyDataSetChanged()
                Toast.makeText(this, "Item adicionado com sucesso", Toast.LENGTH_SHORT).show()

                // Registrar no histórico
                saveToHistory("Adicionado", "O item '$itemName' foi adicionado à lista de compras.")
                ttsManager.speak("O item $itemName foi adicionado com sucesso.")
            }
            .addOnFailureListener { exception ->
                Toast.makeText(this, "Erro ao adicionar item: ${exception.message}", Toast.LENGTH_SHORT).show()
            }
    }

    private fun confirmItem(item: String) {
        val userId = auth.currentUser?.uid ?: return
        firestore.collection("usuarios").document(userId).collection("listaCompra")
            .whereEqualTo("item", item)
            .get()
            .addOnSuccessListener { querySnapshot ->
                for (document in querySnapshot.documents) {
                    val timestamp = System.currentTimeMillis()
                    firestore.collection("usuarios").document(userId).collection("listaCompraRemovidos")
                        .add(mapOf("item" to item, "timestamp" to timestamp))
                        .addOnSuccessListener {
                            document.reference.delete()
                                .addOnSuccessListener {
                                    itemList.remove(item)
                                    adapter.notifyDataSetChanged()
                                    Toast.makeText(this, "Item removido da lista", Toast.LENGTH_SHORT).show()

                                    // Registrar no histórico
                                    saveToHistory("Removido", "O item '$item' foi removido da lista de compras.")
                                    ttsManager.speak("O item $item foi removido da lista.")
                                }
                                .addOnFailureListener { exception ->
                                    Toast.makeText(this, "Erro ao remover item: ${exception.message}", Toast.LENGTH_SHORT).show()
                                }
                        }
                        .addOnFailureListener { exception ->
                            Toast.makeText(this, "Erro ao registrar remoção: ${exception.message}", Toast.LENGTH_SHORT).show()
                        }
                }
            }
            .addOnFailureListener { exception ->
                Toast.makeText(this, "Erro ao confirmar item: ${exception.message}", Toast.LENGTH_SHORT).show()
            }
    }

    private fun saveToHistory(action: String, description: String) {
        val userId = auth.currentUser?.uid ?: return
        val timestamp = System.currentTimeMillis()

        val historyData = mapOf(
            "action" to action,
            "description" to description,
            "timestamp" to timestamp
        )

        firestore.collection("usuarios").document(userId).collection("historico")
            .add(historyData)
            .addOnFailureListener { exception ->
                Toast.makeText(this, "Erro ao registrar histórico: ${exception.message}", Toast.LENGTH_SHORT).show()
            }
    }

    override fun onDestroy() {
        super.onDestroy()
        ttsManager.shutdown()
    }
}
