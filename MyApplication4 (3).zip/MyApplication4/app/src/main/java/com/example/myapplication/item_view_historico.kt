package com.example.myapplication

import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView

class item_view_historico(private val list: List<HistoricoItem>) :
    RecyclerView.Adapter<item_view_historico.MyViewHolder>() {

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): MyViewHolder {
        val view = LayoutInflater.from(parent.context).inflate(R.layout.item_view_historico, parent, false)
        return MyViewHolder(view)
    }

    override fun onBindViewHolder(holder: MyViewHolder, position: Int) {
        val currentItem = list[position]
        holder.title.text = currentItem.title
        holder.description.text = currentItem.description

        // Alternância de cores com base na posição
        holder.itemView.setBackgroundColor(
            if (position % 2 == 0) holder.itemView.context.getColor(R.color.light_yellow)
            else holder.itemView.context.getColor(R.color.dark_yellow)
        )
    }

    override fun getItemCount(): Int = list.size

    class MyViewHolder(itemView: View) : RecyclerView.ViewHolder(itemView) {
        val title: TextView = itemView.findViewById(R.id.tv_title)
        val description: TextView = itemView.findViewById(R.id.tv_description)
    }
}
