import android.content.Context
import android.speech.tts.TextToSpeech
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Button
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView
import com.example.myapplication.R
import java.util.*

data class ReceitaItem(val title: String, val ingredients: String)

class ItemViewReceitasAdapter(
    private val context: Context,
    private val list: List<ReceitaItem>
) : RecyclerView.Adapter<ItemViewReceitasAdapter.MyViewHolder>(), TextToSpeech.OnInitListener {

    private var tts: TextToSpeech = TextToSpeech(context, this)

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): MyViewHolder {
        val view = LayoutInflater.from(parent.context).inflate(R.layout.item_view_receitas, parent, false)
        return MyViewHolder(view)
    }

    override fun onBindViewHolder(holder: MyViewHolder, position: Int) {
        val currentItem = list[position]
        holder.textViewTitle.text = currentItem.title
        holder.textViewIngredients.text = currentItem.ingredients

        // Configurar botão para ler a receita
        holder.readButton.setOnClickListener {
            val textToSpeak = "Receita: ${currentItem.title}. Ingredientes: ${currentItem.ingredients}"
            tts.speak(textToSpeak, TextToSpeech.QUEUE_FLUSH, null, null)
        }
    }

    override fun getItemCount(): Int = list.size

    override fun onInit(status: Int) {
        if (status == TextToSpeech.SUCCESS) {
            tts.language = Locale.getDefault()
        }
    }

    fun shutdownTTS() {
        tts.shutdown()
    }

    class MyViewHolder(itemView: View) : RecyclerView.ViewHolder(itemView) {
        val textViewTitle: TextView = itemView.findViewById(R.id.tv_recipe_title)
        val textViewIngredients: TextView = itemView.findViewById(R.id.tv_recipe_ingredients)
        val readButton: Button = itemView.findViewById(R.id.btn_read_recipe)
    }
}
