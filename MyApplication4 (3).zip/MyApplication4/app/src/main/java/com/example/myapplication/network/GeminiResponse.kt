package com.example.myapplication.network

data class GeminiResponse(
    val text: String? // ou ajuste conforme a estrutura do JSON retornado
)
