package com.example.myapplication

import android.content.Intent
import android.os.Bundle
import android.widget.ImageView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.firestore.FirebaseFirestore

data class HistoricoItem(val title: String, val description: String, val timestamp: Long)

class Historico : AppCompatActivity() {
    private lateinit var recyclerView: RecyclerView
    private lateinit var firestore: FirebaseFirestore
    private lateinit var auth: FirebaseAuth
    private val historyItems = mutableListOf<HistoricoItem>()
    private lateinit var ttsManager: TTSManager

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_historico)

        // Inicializar TTS
        ttsManager = TTSManager(this)

        // Inicializar Firebase
        auth = FirebaseAuth.getInstance()
        firestore = FirebaseFirestore.getInstance()

        // Inicializar RecyclerView
        recyclerView = findViewById(R.id.recycler_historico)
        recyclerView.layoutManager = LinearLayoutManager(this)

        // Configurar Navbar e Botão de Voltar
        setupNavbar()
        setupBackButton()

        // Carregar os dados do histórico
        loadHistorico()
    }

    private fun setupNavbar() {
        val btnMenuPrincipal = findViewById<ImageView>(R.id.btnMenuPrincipal)
        val btnConfig = findViewById<ImageView>(R.id.btnConfig)
        val btnMicrophone = findViewById<ImageView>(R.id.btnMicrophone)
        val btnCamera = findViewById<ImageView>(R.id.btnCamera)

        btnMenuPrincipal.setOnClickListener {
            finish()
        }

        btnConfig.setOnClickListener {
            startActivity(Intent(this, Configuracoes::class.java))
        }

        btnMicrophone.setOnClickListener {
            ttsManager.speak("Na tela de Histórico, você pode visualizar todas as ações realizadas no aplicativo.")
            Toast.makeText(this, "Text-to-Speech acionado.", Toast.LENGTH_SHORT).show()
        }

        btnCamera.setOnClickListener {
            startActivity(Intent(this, GeminiMenu::class.java))
        }
    }

    private fun setupBackButton() {
        val btnBack = findViewById<ImageView>(R.id.btnBack)
        btnBack.setOnClickListener {
            finish()
        }
    }

    private fun loadHistorico() {
        val userId = auth.currentUser?.uid ?: return

        // Carregar ações da lista de compras
        loadListas(userId)

        // Carregar ações do plano alimentar
        loadPlanosAlimentares(userId)

        // Carregar ações do diário
        loadDiario(userId)
    }

    private fun loadListas(userId: String) {
        // Registro de itens adicionados
        firestore.collection("usuarios").document(userId).collection("listaCompra")
            .get()
            .addOnSuccessListener { querySnapshot ->
                for (document in querySnapshot.documents) {
                    val item = document.getString("item") ?: "Item desconhecido"
                    val timestamp = document.getLong("timestamp") ?: System.currentTimeMillis()

                    historyItems.add(
                        HistoricoItem(
                            title = "Lista de Compras",
                            description = "O item '$item' foi adicionado.",
                            timestamp = timestamp
                        )
                    )
                }
                updateRecyclerView()
            }
            .addOnFailureListener { exception ->
                Toast.makeText(this, "Erro ao carregar lista de compras: ${exception.message}", Toast.LENGTH_SHORT).show()
            }

        // Registro de itens removidos
        firestore.collection("usuarios").document(userId).collection("listaCompraRemovidos")
            .get()
            .addOnSuccessListener { querySnapshot ->
                for (document in querySnapshot.documents) {
                    val item = document.getString("item") ?: "Item desconhecido"
                    val timestamp = document.getLong("timestamp") ?: System.currentTimeMillis()

                    historyItems.add(
                        HistoricoItem(
                            title = "Lista de Compras",
                            description = "O item '$item' foi removido.",
                            timestamp = timestamp
                        )
                    )
                }
                updateRecyclerView()
            }
            .addOnFailureListener { exception ->
                Toast.makeText(this, "Erro ao carregar itens removidos da lista de compras: ${exception.message}", Toast.LENGTH_SHORT).show()
            }
    }

    private fun loadPlanosAlimentares(userId: String) {
        // Registro de refeições adicionadas
        firestore.collection("atividades").document(userId).collection("planoAlimentar")
            .get()
            .addOnSuccessListener { querySnapshot ->
                for (document in querySnapshot.documents) {
                    val refeicao = document.getString("refeicao") ?: "Sem nome"
                    val hora = document.getString("hora") ?: "Sem horário"
                    val timestamp = document.getLong("timestamp") ?: System.currentTimeMillis()

                    historyItems.add(
                        HistoricoItem(
                            title = "Plano Alimentar",
                            description = "Refeição '$refeicao' foi adicionada às $hora.",
                            timestamp = timestamp
                        )
                    )
                }
                updateRecyclerView()
            }
            .addOnFailureListener { exception ->
                Toast.makeText(this, "Erro ao carregar plano alimentar: ${exception.message}", Toast.LENGTH_SHORT).show()
            }

        // Registro de refeições removidas
        firestore.collection("atividades").document(userId).collection("planoAlimentarRemovidos")
            .get()
            .addOnSuccessListener { querySnapshot ->
                for (document in querySnapshot.documents) {
                    val refeicao = document.getString("refeicao") ?: "Sem nome"
                    val quemRemoveu = document.getString("removidoPor") ?: "Indefinido"
                    val timestamp = document.getLong("timestamp") ?: System.currentTimeMillis()

                    historyItems.add(
                        HistoricoItem(
                            title = "Plano Alimentar",
                            description = "Refeição '$refeicao' foi removida por $quemRemoveu.",
                            timestamp = timestamp
                        )
                    )
                }
                updateRecyclerView()
            }
            .addOnFailureListener { exception ->
                Toast.makeText(this, "Erro ao carregar itens removidos do plano alimentar: ${exception.message}", Toast.LENGTH_SHORT).show()
            }
    }

    private fun loadDiario(userId: String) {
        firestore.collection("atividades").document(userId).collection("diario")
            .get()
            .addOnSuccessListener { querySnapshot ->
                for (document in querySnapshot.documents) {
                    val atividade = document.getString("atividade") ?: "Atividade desconhecida"
                    val dataHora = "${document.getString("data") ?: "Data desconhecida"} - ${document.getString("hora") ?: "Hora desconhecida"}"
                    val timestamp = document.getLong("timestamp") ?: System.currentTimeMillis()

                    historyItems.add(
                        HistoricoItem(
                            title = "Diário",
                            description = "Atividade registrada: '$atividade' em $dataHora.",
                            timestamp = timestamp
                        )
                    )
                }
                updateRecyclerView()
            }
            .addOnFailureListener { exception ->
                Toast.makeText(this, "Erro ao carregar diário: ${exception.message}", Toast.LENGTH_SHORT).show()
            }
    }

    private fun updateRecyclerView() {
        // Ordena a lista por timestamp em ordem decrescente
        historyItems.sortByDescending { it.timestamp }
        val adapter = item_view_historico(historyItems)
        recyclerView.adapter = adapter
    }

    override fun onDestroy() {
        super.onDestroy()
        ttsManager.shutdown() // Libera recursos do TTS
    }
}
