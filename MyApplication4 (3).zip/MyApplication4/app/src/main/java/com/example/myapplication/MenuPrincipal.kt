package com.example.myapplication

import android.content.Intent
import android.os.Bundle
import android.view.View
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.firestore.FirebaseFirestore

class MenuPrincipal : AppCompatActivity() {
    private lateinit var auth: FirebaseAuth
    private lateinit var firestore: FirebaseFirestore
    private var isNutricionista: Boolean? = null
    private lateinit var ttsManager: TTSManager

    override fun onCreate(savedInstanceState: Bundle?) {

        super.onCreate(savedInstanceState)
        ttsManager = TTSManager(this)

        // Ativar comportamento que respeita a navbar e barra de notificações
        window.decorView.systemUiVisibility = (
                View.SYSTEM_UI_FLAG_LAYOUT_STABLE or
                        View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN or
                        View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION
                )
        setContentView(R.layout.activity_menu_principal)

        // Inicializar Firebase Auth e Firestore
        auth = FirebaseAuth.getInstance()
        firestore = FirebaseFirestore.getInstance()

        // Verificar tipo de usuário
        checkUserType { isNutricionista ->
            this.isNutricionista = isNutricionista
        }

        // Configurar clique dos botões
        setupClickListeners()
    }

    private fun setupClickListeners() {
        findViewById<LinearLayout>(R.id.btnPlano).setOnClickListener {
            if (isNutricionista == true) {
                val intent = Intent(this, PlanoAlimentarNutri::class.java)
                startActivity(intent)
            } else if (isNutricionista == false) {
                val intent = Intent(this, PlaneAlimentar::class.java)
                startActivity(intent)
            } else {
                showToast("Aguarde enquanto carregamos as informações do seu perfil.")
            }
        }

        findViewById<LinearLayout>(R.id.btnDiario).setOnClickListener {
            startActivity(Intent(this, Diario::class.java))
        }

        findViewById<LinearLayout>(R.id.btnListaCompra).setOnClickListener {
            startActivity(Intent(this, ListaCompra::class.java))
        }

        findViewById<LinearLayout>(R.id.btnHistorico).setOnClickListener {
            startActivity(Intent(this, Historico::class.java))
        }

        findViewById<LinearLayout>(R.id.btnReceitas).setOnClickListener {
            startActivity(Intent(this, Receitas::class.java))
        }

        findViewById<ImageView>(R.id.btnConfig).setOnClickListener {
            startActivity(Intent(this, Configuracoes::class.java))
        }
        findViewById<ImageView>(R.id.btnCamera).setOnClickListener {
            startActivity(Intent(this, GeminiMenu::class.java))
        }
        findViewById<ImageView>(R.id.btnMicrophone).setOnClickListener {
            ttsManager.speak("Tela de Menu Principal, você pode acessar Diario,Lista de compra,Historico,Plano Alimentar,Receitas.")
            Toast.makeText(this, "Text-to-Speech acionado.", Toast.LENGTH_SHORT).show()
        }


    }

    private fun checkUserType(callback: (Boolean) -> Unit) {
        val currentUser = auth.currentUser
        if (currentUser != null) {
            val userId = currentUser.uid
            firestore.collection("usuarios").document(userId)
                .get()
                .addOnSuccessListener { document ->
                    if (document.exists()) {
                        val isNutricionista = document.getBoolean("nutricionista") == true
                        callback(isNutricionista)
                    } else {
                        callback(false)
                    }
                }
                .addOnFailureListener {
                    callback(false)
                }
        } else {
            callback(false)
        }
    }

    private fun showToast(message: String) {
        Toast.makeText(this, message, Toast.LENGTH_SHORT).show()
    }

    override fun onDestroy() {
        super.onDestroy()
        ttsManager.shutdown() // Libera recursos do TTS
    }
}
