package com.example.myapplication

import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ImageButton
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView

class PlanoAlimentarAdapter(
    private val list: List<PlanoAlimentarItem>
) : RecyclerView.Adapter<PlanoAlimentarAdapter.MyViewHolder>() {

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): MyViewHolder {
        val view = LayoutInflater.from(parent.context).inflate(R.layout.item_view_plano, parent, false)
        return MyViewHolder(view)
    }

    override fun onBindViewHolder(holder: MyViewHolder, position: Int) {
        val currentItem = list[position]
        holder.textViewRefeicao.text = currentItem.refeicao
        holder.textViewHora.text = currentItem.hora
    }

    override fun getItemCount(): Int = list.size

    class MyViewHolder(itemView: View) : RecyclerView.ViewHolder(itemView) {
        val textViewRefeicao: TextView = itemView.findViewById(R.id.tv_meal_name)
        val textViewHora: TextView = itemView.findViewById(R.id.tv_meal_time)
    }
}
