package com.example.myapplication

import android.annotation.SuppressLint
import android.content.Intent
import android.os.Bundle
import android.widget.*
import androidx.appcompat.app.AppCompatActivity
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.firestore.FirebaseFirestore

class Configuracoes : AppCompatActivity() {

    private lateinit var etName: EditText
    private lateinit var etAge: EditText
    private lateinit var etWeight: EditText
    private lateinit var etHeight: EditText
    private lateinit var etConditions: EditText
    private lateinit var btnSave: Button
    private lateinit var ttsManager: TTSManager

    private val firestore by lazy { FirebaseFirestore.getInstance() }
    private val currentUser by lazy { FirebaseAuth.getInstance().currentUser }

    override fun onCreate(savedInstanceState: Bundle?) {
        ttsManager = TTSManager(this)

        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_configuracoes)

        // Inicializar os componentes
        etName = findViewById(R.id.etName)
        etAge = findViewById(R.id.etAge)
        etWeight = findViewById(R.id.etWeight)
        etHeight = findViewById(R.id.etHeight)
        etConditions = findViewById(R.id.etConditions)
        btnSave = findViewById(R.id.btnSaveInfo)

        // Inicializar os botões da barra de navegação
        val btnMenuPrincipal = findViewById<ImageView>(R.id.btnMenuPrincipal)
        val btnConfig = findViewById<ImageView>(R.id.btnConfig)
        val btnMicrophone = findViewById<ImageView>(R.id.btnMicrophone)
        val btnCamera = findViewById<ImageView>(R.id.btnCamera)
        val btnSuporte = findViewById<LinearLayout>(R.id.btnSuporte)

        // Navegação e ações
        btnMenuPrincipal.setOnClickListener {
            finish()
            startActivity(Intent(this, MenuPrincipal::class.java))
        }

        btnSuporte.setOnClickListener {
            finish()
            startActivity(Intent(this, Suporte::class.java))
        }

        btnConfig.setOnClickListener {
            finish()
            startActivity(Intent(this, Configuracoes::class.java))
        }

        btnMicrophone.setOnClickListener {
            ttsManager.speak("Na tela de configurações, você pode preencher e visualizar informações pessoais.")
            Toast.makeText(this, "Text-to-Speech acionado.", Toast.LENGTH_SHORT).show()
        }

        btnCamera.setOnClickListener {
            finish()
            startActivity(Intent(this, GeminiMenu::class.java))
        }

        btnSave.setOnClickListener {
            saveOrUpdateUserInfo()
        }

        // Carregar informações do usuário
        loadUserInfo()
    }

    private fun loadUserInfo() {
        if (currentUser != null) {
            val userId = currentUser!!.uid

            firestore.collection("usuarios")
                .document(userId)
                .collection("infoUsuario")
                .document("dados")
                .get()
                .addOnSuccessListener { document ->
                    if (document.exists()) {
                        etName.setText(document.getString("nome"))
                        etAge.setText(document.getLong("idade")?.toString())
                        etWeight.setText(document.getString("peso"))
                        etHeight.setText(document.getString("altura"))
                        etConditions.setText(document.getString("condicoes"))
                    } else {
                        Toast.makeText(this, "Nenhum dado encontrado.", Toast.LENGTH_SHORT).show()
                    }
                }
                .addOnFailureListener { e ->
                    Toast.makeText(this, "Erro ao carregar informações: ${e.message}", Toast.LENGTH_SHORT).show()
                }
        } else {
            Toast.makeText(this, "Usuário não autenticado.", Toast.LENGTH_SHORT).show()
        }
    }

    private fun saveOrUpdateUserInfo() {
        if (currentUser != null) {
            val userId = currentUser!!.uid

            val userInfo = mapOf(
                "nome" to etName.text.toString(),
                "idade" to etAge.text.toString().toIntOrNull(),
                "peso" to etWeight.text.toString(),
                "altura" to etHeight.text.toString(),
                "condicoes" to etConditions.text.toString()
            )

            firestore.collection("usuarios")
                .document(userId)
                .collection("infoUsuario")
                .document("dados")
                .set(userInfo)
                .addOnSuccessListener {
                    Toast.makeText(this, "Informações salvas com sucesso!", Toast.LENGTH_SHORT).show()
                }
                .addOnFailureListener { e ->
                    Toast.makeText(this, "Erro ao salvar informações: ${e.message}", Toast.LENGTH_SHORT).show()
                }
        } else {
            Toast.makeText(this, "Usuário não autenticado.", Toast.LENGTH_SHORT).show()
        }
    }
    override fun onDestroy() {
        super.onDestroy()
        ttsManager.shutdown() // Libera recursos do TTS
    }
}
